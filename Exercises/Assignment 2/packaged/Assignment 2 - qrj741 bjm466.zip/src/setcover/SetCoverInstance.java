package setcover;

import java.util.HashSet;
import java.util.Set;

public class SetCoverInstance {
    public final String fileName;
    public final int n; // number of sets
    public final int m; // number of elements in universe
    public final IsIn[] covers; //
    public final int[] costs;
    public final int f;

    public SetCoverInstance(String fileName, int n, int m, IsIn[] covers, int[] costs) {
        this.fileName = fileName;
        this.n = n;
        this.m = m;
        this.covers = covers;
        this.costs = costs;

        //noinspection unchecked
        Set<Integer>[] sets = (Set<Integer>[]) new Set[n];

        for (IsIn cover : covers) {
            if (sets[cover.set] == null) {
                sets[cover.set] = new HashSet<>();
            }
            sets[cover.set].add(cover.element);
        }

        int f = 0;

        for (Set<Integer> set : sets) {
            if (f < set.size()) {
                f = set.size();
            }
        }

        this.f = f;
    }
}
