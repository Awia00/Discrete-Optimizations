package setcover;

public class IsIn {
    public final int element;
    // is in
    public final int set;

    public IsIn(int element, int set) {
        this.element = element;
        this.set = set;
    }
}
