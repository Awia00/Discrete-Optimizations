package setcover.solvers;

import setcover.SetCoverInstance;

public interface SetCoverSolver {
    int solveSetCover(SetCoverInstance instance);
}
